
export const MONTH_NAMES = [
  'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
  'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
];

export const IVA_RATE_GENERAL = 0.13; // 13%
export const RENTA_DEDUCTION_RATE = 0.15; // 15% fixed deduction
export const RENTA_TAX_RATE = 0.15; // 15% tax on net
